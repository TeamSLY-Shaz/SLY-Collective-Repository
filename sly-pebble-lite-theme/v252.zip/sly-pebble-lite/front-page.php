<?php
if (!defined('ABSPATH')) {
	exit;
}

get_header();

// ── Hero vars ────────────────────────────────────────────────────────────────
$hero_kicker    = '> NO CHAFE. NO COMPROMISE. NO EXCEPTIONS.';
$hero_cta_label = get_theme_mod('sly_hero_cta_label', 'Shop Best Sellers');
$hero_cta_default = home_url('/product-category/men-underwear/mens-pouch-underwear/?orderby=popularity');
$hero_cta_url   = get_theme_mod('sly_hero_cta_url', $hero_cta_default);
// v242/v252: /shop resolves to the wrong page, and the plain category link
// isn't sorted by best sellers — treat either saved value as unset.
$hero_cta_legacy = array('/shop', untrailingslashit(home_url('/shop')), untrailingslashit(home_url('/product-category/men-underwear/mens-pouch-underwear')));
if (in_array(untrailingslashit($hero_cta_url), $hero_cta_legacy, true)) {
	$hero_cta_url = $hero_cta_default;
}
$hero_cta2_url  = get_theme_mod('sly_hero_cta2_url', home_url('/about-us/'));
if (untrailingslashit($hero_cta2_url) === untrailingslashit(home_url('/about-us'))) {
	$hero_cta2_url = home_url('/about-us/');
}
// v252: hero is a real <img> (early-discovered LCP, alt text, width/height
// to stop layout shift). The theme's images are always used — a saved
// Customizer hero image is ignored so it can't swap in or get preloaded.
$hero_alt        = 'Man in SLY Collective bamboo pouch trunks in boxing, sprint-start and sit-up poses';
$hero_img_dir    = get_template_directory_uri() . '/assets/images/';
$hero_src        = $hero_img_dir . 'hero-model.webp';
$hero_src_mobile = $hero_img_dir . 'hero-model-mobile.webp';
$hero_srcset     = $hero_img_dir . 'hero-model-1400.webp 1400w, ' . $hero_img_dir . 'hero-model-1920.webp 1920w, ' . $hero_src . ' 2400w';
$hero_w          = 2400;
$hero_h          = 1340;

// ── Page vars ────────────────────────────────────────────────────────────────
$home_feature_tiles           = array(
	array(
		'title' => get_theme_mod('sly_home_feature_1_title', 'ANTI-CHAFE. NO RIDE UP.'),
		'text'  => get_theme_mod('sly_home_feature_1_text', 'For blokes who\'ve had enough of the old thigh rub, ball chafe, and constant awkward adjustments.'),
	),
	array(
		'title' => get_theme_mod('sly_home_feature_2_title', 'SUPPORTIVE POUCH'),
		'text'  => get_theme_mod('sly_home_feature_2_text', 'Built to lift, support and keep the boys in their comfort zone — secure, comfortable and ready for workouts, ageing bodies, and recovery days that need a little extra TLC.'),
	),
	array(
		'title' => get_theme_mod('sly_home_feature_3_title', 'ROOM TO BREATHE'),
		'text'  => get_theme_mod('sly_home_feature_3_text', 'Extra space up front means less sticking and less squeezing because downstairs traffic jams are not a vibe.'),
	),
);
$home_best_sellers_heading    = get_theme_mod('sly_home_best_sellers_heading', 'Best Sellers');
$home_best_sellers_cta        = get_theme_mod('sly_home_best_sellers_cta', 'View All');
$home_best_sellers_empty_text = get_theme_mod('sly_home_best_sellers_empty_text', 'Add products in WooCommerce to populate this section.');
$home_trust_heading           = get_theme_mod('sly_home_trust_heading', 'Comfort You Can Trust');
$home_trust_text              = get_theme_mod('sly_home_trust_text', 'Free AU shipping over $100. Hassle-free returns. Secure checkout with encrypted payments. Thousands of happy customers across Australia.');
$benefits_img                 = get_template_directory_uri() . '/assets/images/benefits/';
$benefits_product_img         = get_theme_mod('sly_benefits_product_image', 'https://slycollective.com/wp-content/uploads/2026/07/Pouch-Diagram-2.jpg');
?>

<!-- ── All homepage styles (single block) ───────────────────────────────── -->
<style>
/* Poppins override */
.home .site-main p,.home .site-main li,.home .site-main span:not(.brandmark__primary):not(.brandmark__secondary):not(.hero__line),.home .site-main a,.home .site-main label,.home .site-main small,.home .site-main td,.home .site-main th,.home .site-main blockquote,.home .site-main figcaption{font-family:"Poppins",Arial,sans-serif!important}
/* Hero title — Anton to match section headlines */
.hero__title--bold,.hero__title--bold .hero__line{font-family:"Anton",Impact,"Arial Narrow",sans-serif!important;font-weight:400!important;letter-spacing:-0.01em!important;text-transform:uppercase!important}
/* Problem section */
.sly-problem{background:#111;padding:72px 0 32px;font-family:Poppins,Arial,sans-serif}
.sly-problem__eyebrow{margin:0 0 18px;font-size:12px!important;font-weight:700!important;letter-spacing:3px;text-transform:uppercase;color:#FF4419}
.sly-problem__headline{margin:0 0 56px;font-family:"Anton",Impact,"Arial Narrow",sans-serif!important;font-size:clamp(38px,6vw,80px)!important;font-weight:400!important;line-height:1.0!important;letter-spacing:-0.01em!important;text-transform:uppercase!important;color:#fff!important}
.sly-problem__headline .strike{color:#555;text-decoration:line-through;text-decoration-color:#FF4419;text-decoration-thickness:3px}
.sly-problem__grid{display:grid;grid-template-columns:repeat(4,1fr);gap:0;border-top:1px solid rgba(255,255,255,0.1)}
.sly-problem__card{padding:32px 28px;border-right:1px solid rgba(255,255,255,0.1)}
.sly-problem__card:last-child{border-right:none}
.sly-problem__icon{margin-bottom:20px;color:#FF4419;font-size:22px;line-height:1}
.sly-problem__card-title{margin:0 0 10px;font-size:17px!important;font-weight:700!important;line-height:1.25;color:#fff;text-transform:none;letter-spacing:0}
.sly-problem__card-text{margin:0;font-family:"Poppins",Arial,sans-serif!important;font-size:13.5px!important;font-weight:300!important;line-height:1.55;color:#fff!important}
/* Benefits split */
.sly-benefits-split{display:grid;grid-template-columns:1fr 1fr;align-items:stretch;gap:0}
.sly-benefits-split__left{background:#fff;padding:28px 0 28px 28px;box-sizing:border-box;display:flex;align-items:center;justify-content:center}
.sly-benefits-split__right{overflow:hidden;min-height:420px;display:flex;align-items:center;justify-content:flex-start;background:#fff}
.sly-benefits-split__right img{display:block;width:70%;height:auto;object-fit:contain}
.sly-benefits-split .sly-benefits__grid{display:grid;grid-template-columns:1fr 1fr;gap:16px 24px;width:100%;max-width:420px}
.sly-benefits-split .sly-benefit{display:flex;flex-direction:column;align-items:center;text-align:center}
.sly-benefits-split .sly-benefit__note{width:63%;margin:0 auto}
.sly-benefits-split .sly-benefit__note img{display:block;width:100%;height:auto}
.sly-benefits-split .sly-benefit__desc{margin:6px 0 0;font-family:"Poppins",Arial,sans-serif;font-size:12px;font-weight:400;line-height:1.35;color:#444;text-align:center}
/* Upgrade section */
.sly-upgrade{background:#fff;padding:0 0 64px;font-family:Poppins,Arial,sans-serif;text-align:center}
.sly-upgrade__eyebrow{margin:0 0 18px;font-size:22px!important;font-weight:300!important;letter-spacing:0.08em;text-transform:uppercase;color:#00b8c4!important}
.sly-upgrade__headline{margin:0 0 28px;font-family:"Anton",Impact,"Arial Narrow",sans-serif!important;font-size:clamp(38px,6vw,80px)!important;font-weight:400!important;line-height:1.0!important;letter-spacing:-0.01em!important;text-transform:uppercase!important;color:#000!important;text-align:center!important}
.sly-upgrade__body{margin:0 auto;font-family:"Poppins",Arial,sans-serif!important;font-size:15px!important;font-weight:400!important;line-height:1.4;color:#000!important;max-width:640px;text-align:center}
/* Feature pillars */
.sly-pillars{background:#111;padding:72px 0;font-family:Poppins,Arial,sans-serif}
.sly-pillars__grid{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid rgba(255,255,255,0.08)}
.sly-pillar{padding:36px 28px;border-right:1px solid rgba(255,255,255,0.08);position:relative}
.sly-pillar:last-child{border-right:none}
.sly-pillar__num{position:absolute;top:24px;right:20px;font-size:56px;font-weight:700;line-height:1;color:#3789A3;font-family:Poppins,Arial,sans-serif;letter-spacing:-0.02em}
.sly-pillar__title{margin:0 0 16px;font-size:17px!important;font-weight:600!important;color:#fff;line-height:1.25;text-transform:none;letter-spacing:0;padding-right:48px;padding-bottom:12px;border-bottom:2px solid #3789A3}
.sly-pillar__text{margin:0;font-size:13.5px!important;font-weight:300!important;line-height:1.65;color:#fff!important}
/* Customer review */
.sly-review{background:#0d0d0d;padding:80px 0 72px}
.sly-review__inner{max-width:900px;margin:0 auto;padding:0 24px;position:relative}
.sly-review__quote{font-family:"Anton",Impact,"Arial Narrow",sans-serif!important;font-size:clamp(20px,1.7vw,28px)!important;font-weight:400!important;line-height:1.3!important;letter-spacing:0.01em!important;text-transform:uppercase!important;color:rgba(255,255,255,0.82)!important;margin:0 0 36px;position:relative;padding-top:40px}
.sly-review__quote::before{content:'\201C';font-family:"Anton",Impact,sans-serif;font-size:120px;line-height:0.6;color:#3789A3;position:absolute;top:0;left:-8px;opacity:0.9}
.sly-review__attr{font-family:"Poppins",Arial,sans-serif!important;font-size:14px!important;font-weight:400!important;color:rgba(255,255,255,0.4)!important;letter-spacing:0.05em;text-transform:none}
.sly-review__attr::before{content:'— '}
/* v244: desktop review quote — much larger to grab attention (tablet/mobile unchanged) */
@media(min-width:861px){
  .sly-review__quote{font-size:clamp(28px,2.6vw,40px)!important;line-height:1.2!important;padding-top:64px}
  .sly-review__quote::before{font-size:150px}
  .sly-review__attr{font-size:18px!important;margin-top:8px}
}
/* Responsive */
@media(max-width:860px){
  .sly-problem{padding:52px 0 20px}
  .sly-problem__grid{grid-template-columns:repeat(2,1fr)}
  .sly-problem__card{border-right:none;border-bottom:1px solid rgba(255,255,255,0.1);padding:28px 20px}
  .sly-problem__card:nth-child(odd){border-right:1px solid rgba(255,255,255,0.1)}
  .sly-problem__card:nth-last-child(-n+2){border-bottom:none}
  .sly-benefits-split{grid-template-columns:1fr}
  .sly-benefits-split__left{padding:16px 12px;justify-content:center}
  .sly-benefits-split__right{min-height:240px;justify-content:center}
  .sly-benefits-split__right img{margin:0 auto}
  .sly-benefits-split .sly-benefits__grid{gap:10px 14px;max-width:100%}
  .sly-benefits-split .sly-benefit__note{width:58%}
  .sly-benefits-split .sly-benefit__desc{font-size:11px;margin-top:4px}
  .sly-upgrade{padding:0 0 48px}
  .sly-upgrade__headline{font-size:clamp(32px,7vw,60px)!important}
  .sly-upgrade__eyebrow{font-size:18px!important}
  .sly-pillars{padding:52px 0}
  .sly-pillars__grid{grid-template-columns:repeat(2,1fr)}
  .sly-pillar{border-right:none;border-bottom:1px solid rgba(255,255,255,0.08);padding:28px 20px}
  .sly-pillar:nth-child(odd){border-right:1px solid rgba(255,255,255,0.08)}
  .sly-pillar:nth-last-child(-n+2){border-bottom:none}
  .sly-review__quote{font-size:clamp(17px,2.4vw,22px)!important;line-height:1.4!important}
}
@media(max-width:480px){
  .sly-problem{padding:40px 0 8px}
  .sly-problem__headline{margin-bottom:36px}
  .sly-benefits-split__left{padding:12px 8px;justify-content:center}
  .sly-benefits-split .sly-benefits__grid{gap:8px 10px}
  .sly-benefits-split .sly-benefit__note{width:55%}
  .sly-benefits-split .sly-benefit__desc{font-size:10.5px;margin-top:3px}
  .sly-upgrade{padding:0 0 36px}
  .sly-upgrade__headline{margin-bottom:20px}
  .sly-upgrade__eyebrow{font-size:clamp(14px,5vw,18px)!important}
  .sly-pillars{padding:40px 0}
  .sly-pillars__grid{grid-template-columns:1fr}
  .sly-pillar{border-right:none!important;border-bottom:1px solid rgba(255,255,255,0.08);padding:24px 0}
  .sly-pillar:last-child{border-bottom:none}
  .sly-pillar__num{font-size:44px;top:16px;right:0}
  .sly-review{padding:56px 0 48px}
  .sly-review__quote{font-size:clamp(16px,4.5vw,20px)!important;line-height:1.45!important;padding-top:32px}
  .sly-review__quote::before{font-size:80px}
}
</style>

<?php /* v252: full-bleed hero — original photo under a black gradient layer
   (lighter over the models, darker behind the text). Vertical 3:4 image on
   mobile, full width on desktop. No data-reveal: the hero is the LCP element. */ ?>
<style>
.sly-hero{position:relative;width:100%;background:#000;overflow:hidden;display:flex;align-items:flex-end;aspect-ratio:3/4;isolation:isolate}
.sly-hero__media{position:absolute;inset:0;z-index:-2}
.sly-hero__media picture,.sly-hero__media img{display:block;width:100%;height:100%}
.sly-hero__media img{object-fit:cover;object-position:center top}
.sly-hero::after{content:"";position:absolute;inset:0;z-index:-1;pointer-events:none;background:linear-gradient(0deg,rgba(0,0,0,.9) 0%,rgba(0,0,0,.82) 30%,rgba(0,0,0,.45) 52%,rgba(0,0,0,.22) 72%,rgba(0,0,0,.18) 100%)}
.sly-hero__content{box-sizing:border-box;width:100%;padding:0 1.15rem 1.5rem}
.sly-hero__kicker{margin:0 0 .5rem!important;color:#fff!important;font-weight:700!important;font-size:.7rem!important;letter-spacing:.16em!important;text-transform:uppercase;line-height:1.45}
.sly-hero h1.hero__title--bold{margin:0!important;display:flex;flex-direction:column;font-size:clamp(2.6rem,12.5vw,4.2rem)!important;line-height:.92!important;color:#fff!important}
.sly-hero .hero__line{display:block;color:#fff!important}
.sly-hero .hero__line--accent{color:#FF4419!important}
.sly-hero__actions{display:flex;gap:.6rem;margin-top:1.1rem}
.sly-hero__actions .sly-button{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;flex:0 1 auto;min-height:46px;padding:.65rem 1.1rem!important;background:#fff!important;color:#FF4419!important;border:none!important;border-radius:5px!important;font-size:.8rem!important;font-weight:400!important;letter-spacing:.02em;line-height:1.2!important;white-space:nowrap;box-shadow:0 6px 18px rgba(0,0,0,.25);transition:background .2s ease,color .2s ease}
.sly-hero__actions .sly-button:hover,.sly-hero__actions .sly-button:focus-visible{background:#FF4419!important;color:#fff!important}
.sly-hero__actions .sly-button:focus-visible{outline:2px solid #fff;outline-offset:3px}
@media(min-width:900px){
  .sly-hero{aspect-ratio:auto;height:clamp(520px,55.9vw,960px);align-items:center}
  .sly-hero__media img{object-position:center 55%}
  .sly-hero::after{background:linear-gradient(90deg,rgba(0,0,0,.88) 0%,rgba(0,0,0,.8) 28%,rgba(0,0,0,.5) 45%,rgba(0,0,0,.25) 60%,rgba(0,0,0,.2) 100%)}
  .sly-hero__content{padding:0 0 0 clamp(2rem,6vw,8rem);max-width:min(780px,48%)}
  .sly-hero__kicker{font-size:clamp(.85rem,1.05vw,1.05rem)!important;margin-bottom:.9rem!important}
  .sly-hero h1.hero__title--bold{font-size:clamp(3.6rem,5.9vw,7.2rem)!important}
  .sly-hero__actions{gap:1.1rem;margin-top:2rem}
  .sly-hero__actions .sly-button{min-height:56px;padding:.95rem 2rem!important;font-size:1.05rem!important}
}
</style>
<section class="sly-hero" aria-labelledby="sly-hero-title">
	<div class="sly-hero__media">
		<picture>
			<source media="(max-width:899px)" srcset="<?php echo esc_url($hero_src_mobile); ?>" width="900" height="1200">
			<img src="<?php echo esc_url($hero_src); ?>" srcset="<?php echo esc_attr($hero_srcset); ?>" sizes="100vw" width="<?php echo (int) $hero_w; ?>" height="<?php echo (int) $hero_h; ?>" alt="<?php echo esc_attr($hero_alt); ?>" fetchpriority="high" loading="eager" decoding="async">
		</picture>
	</div>
	<div class="sly-hero__content">
		<p class="sly-hero__kicker"><?php echo esc_html($hero_kicker); ?></p>
		<h1 id="sly-hero-title" class="hero__title--bold"><span class="hero__line">STOP ADJUSTING.</span> <span class="hero__line hero__line--accent">START LIVING.</span></h1>
		<div class="sly-hero__actions">
			<a class="sly-button sly-hero__cta" href="<?php echo esc_url($hero_cta_url); ?>"><?php echo esc_html($hero_cta_label); ?></a>
			<a class="sly-button sly-hero__ghost" href="<?php echo esc_url($hero_cta2_url); ?>"><?php echo esc_html(get_theme_mod('sly_hero_cta2_label', 'Why SLY?')); ?></a>
		</div>
	</div>
</section>

<section class="sly-problem">
  <div class="container">
    <p class="sly-problem__eyebrow">The Problem</p>
    <h2 class="sly-problem__headline">Standard Underwear <span class="strike">Lies</span> Fails You.</h2>
    <div class="sly-problem__grid">
      <div class="sly-problem__card">
        <div class="sly-problem__icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
        </div>
        <h3 class="sly-problem__card-title">Skin-on-skin friction</h3>
        <p class="sly-problem__card-text">Everything bunches, sticks and shifts. By midday, you're doing the undie shuffle - and downstairs is officially in crisis.</p>
      </div>
      <div class="sly-problem__card">
        <div class="sly-problem__icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <h3 class="sly-problem__card-title">Trapped heat</h3>
        <p class="sly-problem__card-text">Cotton holds the sweat. Synthetics trap the heat. Either way, the boys are slow-roasting — and performance is off the menu.</p>
      </div>
      <div class="sly-problem__card">
        <div class="sly-problem__icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>
        </div>
        <h3 class="sly-problem__card-title">Constant readjusting</h3>
        <p class="sly-problem__card-text">The sneaky crotch shuffle. Everyone does it. Nobody enjoys it. But flat-front pouches leave the boys crammed into economy.</p>
      </div>
      <div class="sly-problem__card">
        <div class="sly-problem__icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/><line x1="12" y1="12" x2="12" y2="16"/><line x1="10" y1="14" x2="14" y2="14"/></svg>
        </div>
        <h3 class="sly-problem__card-title">Zero support structure</h3>
        <p class="sly-problem__card-text">Everything dangles. Nothing supports. By 3pm, gravity's running the show — and the chafe won't clock off until your undies do.</p>
      </div>
    </div>
  </div>
</section>

<?php if (class_exists('WooCommerce')) : ?>
	<section class="container product-strip">
		<div class="section-head" data-reveal>
			<h2><?php echo esc_html($home_best_sellers_heading); ?></h2>
			<a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>"><?php echo esc_html($home_best_sellers_cta); ?></a>
		</div>
		<div class="product-grid">
			<?php
			$products = wc_get_products(array(
				'limit'      => 8,
				'status'     => 'publish',
				'orderby'    => 'date',
				'order'      => 'DESC',
				'visibility' => 'visible',
			));
			if (!empty($products)) {
				foreach ($products as $product) {
					sly_pebble_lite_product_card($product->get_id());
				}
			} else {
				echo '<p>' . esc_html($home_best_sellers_empty_text) . '</p>';
			}
			?>
		</div>
	</section>
<?php endif; ?>

<section class="sly-benefits-split">
  <div class="sly-benefits-split__left">
    <div class="sly-benefits__grid">
      <div class="sly-benefit">
        <div class="sly-benefit__note">
          <img src="<?php echo esc_url($benefits_img . 'no-ball-chafe.webp'); ?>" alt="No ball-chafe. EVER!" width="400" height="391" loading="lazy" decoding="async">
        </div>
        <p class="sly-benefit__desc">Cleverly designed inner pouch that separates. No leg contact. No chafe ever again.</p>
      </div>
      <div class="sly-benefit">
        <div class="sly-benefit__note">
          <img src="<?php echo esc_url($benefits_img . 'more-space.webp'); ?>" alt="More space like a man-cave for your balls" width="400" height="383" loading="lazy" decoding="async">
        </div>
        <p class="sly-benefit__desc">Nothing worse than tight sweaty spaces. Our pouch rolls out the red carpet to spacious comfort.</p>
      </div>
      <div class="sly-benefit">
        <div class="sly-benefit__note">
          <img src="<?php echo esc_url($benefits_img . 'support.webp'); ?>" alt="Support especially during exercise" width="400" height="402" loading="lazy" decoding="async">
        </div>
        <p class="sly-benefit__desc">Proper structured scrotum support that keeps everything in place and reduces discomfort.</p>
      </div>
      <div class="sly-benefit">
        <div class="sly-benefit__note">
          <img src="<?php echo esc_url($benefits_img . 'sperm-health.webp'); ?>" alt="A better chance of healthier sperm" width="400" height="384" loading="lazy" decoding="async">
        </div>
        <p class="sly-benefit__desc">Prevent overheating. Regulates temperature. A crucial factor for the healthiest swimmers.</p>
      </div>
    </div>
  </div>
  <div class="sly-benefits-split__right">
    <img src="<?php echo esc_url($benefits_product_img); ?>" alt="SLY Collective adaptive pouch underwear" width="800" height="800" loading="lazy" decoding="async">
  </div>
</section>

<section class="sly-upgrade">
  <div class="container">
    <p class="sly-upgrade__eyebrow">Lifted. Separated. Supported.</p>
    <h2 class="sly-upgrade__headline">Experience the Upgrade for Yourself.</h2>
    <p class="sly-upgrade__body">SLY Collective underwear isn't about fashion. It's about solving a problem that every man has but nobody talks about. Built by Australians, for Australians — and anyone else who's done with discomfort.</p>
  </div>
</section>

<section class="sly-pillars">
  <div class="container">
    <div class="sly-pillars__grid">
      <div class="sly-pillar">
        <span class="sly-pillar__num">01</span>
        <h3 class="sly-pillar__title">Separation Technology</h3>
        <p class="sly-pillar__text">The engineered inner pouch creates a dedicated zone for everything to sit — lifted, separated, supported. No leg contact. No friction. No chafe. Ever.</p>
      </div>
      <div class="sly-pillar">
        <span class="sly-pillar__num">02</span>
        <h3 class="sly-pillar__title">Bamboo Performance</h3>
        <p class="sly-pillar__text">95% bamboo viscose. Naturally moisture-wicking. Antibacterial without chemical treatment. Thermo-regulating — keeps you cool in Queensland summers and warm in winter.</p>
      </div>
      <div class="sly-pillar">
        <span class="sly-pillar__num">03</span>
        <h3 class="sly-pillar__title">Built-in Pocket</h3>
        <p class="sly-pillar__text">The only pouch underwear brand with a hidden stash pocket. Keys, cards, emergency cash — kept secure and out of your pockets. Perfect for the gym, travel, or a night out.</p>
      </div>
      <div class="sly-pillar">
        <span class="sly-pillar__num">04</span>
        <h3 class="sly-pillar__title">Australian Made</h3>
        <p class="sly-pillar__text">Proudly manufactured in Australia. Reduced carbon footprint, exceptional quality control, and support for local industry. Some things are worth keeping local.</p>
      </div>
    </div>
  </div>
</section>


<section class="sly-review">
  <div class="sly-review__inner">
    <p class="sly-review__quote">The fact that the family jewels are tucked into a supporting pouch, which affords the comfort that my usual briefs didn&#8217;t do. No more, one jewel hanging uncomfortably loose outside of the briefs. No more embarrassing attempts to &#8216;repack&#8217; the package!&#8221;</p>
    <p class="sly-review__attr">Ben G &mdash; Morayfield</p>
  </div>
</section>
<div style="height:64px"></div>

<section class="feature-tiles container">
	<?php foreach ($home_feature_tiles as $feature_tile) : ?>
		<article class="feature-tile" data-reveal>
			<h2><?php echo esc_html($feature_tile['title']); ?></h2>
			<p><?php echo esc_html($feature_tile['text']); ?></p>
		</article>
	<?php endforeach; ?>
</section>

<section class="container social-proof-bar" data-reveal>
	<div class="social-proof-bar__item">
		<span class="social-proof-bar__icon">&#9733;</span>
		<span class="social-proof-bar__stat"><?php echo esc_html(get_theme_mod('sly_proof_rating', '4.8/5')); ?></span>
		<span class="social-proof-bar__label"><?php echo esc_html(get_theme_mod('sly_proof_rating_label', 'Average Rating')); ?></span>
	</div>
	<div class="social-proof-bar__item">
		<span class="social-proof-bar__icon">&#128197;</span>
		<span class="social-proof-bar__stat"><?php echo esc_html(get_theme_mod('sly_proof_customers', '20+ Years')); ?></span>
		<span class="social-proof-bar__label"><?php echo esc_html(get_theme_mod('sly_proof_customers_label', 'Est. 2005')); ?></span>
	</div>
	<div class="social-proof-bar__item">
		<span class="social-proof-bar__icon">&#128230;</span>
		<span class="social-proof-bar__stat"><?php echo esc_html(get_theme_mod('sly_proof_dispatch', '1-2 Days')); ?></span>
		<span class="social-proof-bar__label"><?php echo esc_html(get_theme_mod('sly_proof_dispatch_label', 'Fast Dispatch')); ?></span>
	</div>
	<div class="social-proof-bar__item">
		<span class="social-proof-bar__icon">&#8617;</span>
		<span class="social-proof-bar__stat"><?php echo esc_html(get_theme_mod('sly_proof_returns', '30 Days')); ?></span>
		<span class="social-proof-bar__label"><?php echo esc_html(get_theme_mod('sly_proof_returns_label', 'Easy Returns')); ?></span>
	</div>
</section>

<section class="container trust-band" data-reveal>
	<h2><?php echo esc_html($home_trust_heading); ?></h2>
	<p><?php echo esc_html($home_trust_text); ?></p>
</section>

<?php
get_footer();
