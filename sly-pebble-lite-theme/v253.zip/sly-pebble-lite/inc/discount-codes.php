<?php
/**
 * Discount codes — SLY20 (first order) and COMFYAS (bulk buy).
 *
 * v253
 * - SLY20: first completed order only, per customer. Checked against the
 *   logged-in account and the billing email (guests). Logged-in shoppers are
 *   stopped in the cart; guests are checked as soon as their email is known
 *   and again when the order is placed (block checkout + classic fallback).
 * - COMFYAS: replaces the old automatic bulk-buy fee. Customers enter it
 *   themselves; the % is picked from the cart quantity (7+ 15%, 14+ 20%,
 *   21+ 25%). Built in as a virtual coupon — nothing to create in WP Admin.
 * - One code per order: SLY20 and COMFYAS are both "individual use", so
 *   applying one replaces the other.
 *
 * @package sly-pebble-lite
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'SLY_FIRST_ORDER_CODE' ) ) {
	define( 'SLY_FIRST_ORDER_CODE', 'sly20' );
}
if ( ! defined( 'SLY_BULK_CODE' ) ) {
	define( 'SLY_BULK_CODE', 'comfyas' );
}

/** Bulk tiers, highest first. Shared with the cart progress bar. */
if ( ! function_exists( 'sly_cart_bulk_tiers' ) ) {
	function sly_cart_bulk_tiers() {
		return array(
			array( 'min' => 21, 'pct' => 25 ),
			array( 'min' => 14, 'pct' => 20 ),
			array( 'min' => 7,  'pct' => 15 ),
		);
	}
}

/** Bulk % for a quantity (0 if below the first tier). */
function sly_bulk_pct_for_qty( $qty ) {
	foreach ( sly_cart_bulk_tiers() as $tier ) {
		if ( $qty >= $tier['min'] ) {
			return (int) $tier['pct'];
		}
	}
	return 0;
}

function sly_cart_item_count() {
	return ( function_exists( 'WC' ) && WC()->cart ) ? (int) WC()->cart->get_cart_contents_count() : 0;
}

function sly_is_code( $coupon, $code ) {
	$c = $coupon instanceof WC_Coupon ? $coupon->get_code() : (string) $coupon;
	return wc_strtolower( wc_format_coupon_code( $c ) ) === $code;
}

function sly_first_order_fail_message() {
	return __( 'Code SLY20 is for first purchases only. Looks like you\'ve ordered with us before — thanks for coming back! Buying 7+ items? Try COMFYAS for up to 25% off.', 'sly-pebble-lite' );
}

/**
 * Has this customer placed an order before? Checks the account and the
 * billing email. Counts paid orders plus on-hold (bank transfer etc.).
 */
function sly_customer_has_prior_order( $user_id = 0, $email = '', $exclude_order_id = 0 ) {
	$statuses = array_unique( array_merge( wc_get_is_paid_statuses(), array( 'on-hold' ) ) );
	$base     = array(
		'status'  => $statuses,
		'limit'   => 2,
		'return'  => 'ids',
		'exclude' => $exclude_order_id ? array( $exclude_order_id ) : array(),
	);
	if ( $user_id ) {
		if ( wc_get_orders( $base + array( 'customer_id' => (int) $user_id ) ) ) {
			return true;
		}
		if ( ! $email ) {
			$user  = get_userdata( $user_id );
			$email = $user ? $user->user_email : '';
		}
	}
	$email = sanitize_email( $email );
	if ( $email && is_email( $email ) ) {
		foreach ( array_unique( array( $email, wc_strtolower( $email ) ) ) as $e ) {
			if ( wc_get_orders( $base + array( 'billing_email' => $e ) ) ) {
				return true;
			}
		}
	}
	return false;
}

// ── COMFYAS: virtual coupon, % follows cart quantity ─────────────────────────
add_filter( 'woocommerce_get_shop_coupon_data', function ( $data, $code ) {
	if ( wc_strtolower( wc_format_coupon_code( (string) $code ) ) !== SLY_BULK_CODE ) {
		return $data;
	}
	$pct = sly_bulk_pct_for_qty( sly_cart_item_count() );
	return array(
		'code'           => SLY_BULK_CODE,
		'discount_type'  => 'percent',
		'amount'         => $pct ? $pct : 15, // validity check below blocks < 7 items
		'individual_use' => true,
		'description'    => 'Bulk buy: 15% off 7+, 20% off 14+, 25% off 21+ items.',
	);
}, 10, 2 );

// ── Validity rules for both codes ───────────────────────────────────────────
add_filter( 'woocommerce_coupon_is_valid', function ( $valid, $coupon ) {
	if ( ! $valid ) {
		return $valid;
	}

	if ( sly_is_code( $coupon, SLY_BULK_CODE ) ) {
		$qty  = sly_cart_item_count();
		$min  = 7;
		if ( $qty < $min ) {
			$more = $min - $qty;
			throw new Exception(
				sprintf(
					/* translators: %d: items still needed */
					_n( 'COMFYAS unlocks at 7 items — add %d more item to get 15%% off.', 'COMFYAS unlocks at 7 items — add %d more items to get 15%% off.', $more, 'sly-pebble-lite' ),
					$more
				),
				109
			);
		}
	}

	if ( sly_is_code( $coupon, SLY_FIRST_ORDER_CODE ) ) {
		$user_id = get_current_user_id();
		$email   = ( function_exists( 'WC' ) && WC()->customer ) ? WC()->customer->get_billing_email() : '';
		if ( ( $user_id || $email ) && sly_customer_has_prior_order( $user_id, $email ) ) {
			throw new Exception( sly_first_order_fail_message(), 109 );
		}
	}

	return $valid;
}, 20, 2 );

// SLY20 is always "individual use", whatever the admin setting says.
add_filter( 'woocommerce_coupon_get_individual_use', function ( $value, $coupon ) {
	return sly_is_code( $coupon, SLY_FIRST_ORDER_CODE ) ? true : $value;
}, 10, 2 );

// Let SLY20/COMFYAS replace an already-applied single-use code instead of
// WooCommerce refusing with "cannot be used in conjunction".
add_filter( 'woocommerce_apply_with_individual_use_coupon', function ( $allow, $the_coupon ) {
	return ( sly_is_code( $the_coupon, SLY_FIRST_ORDER_CODE ) || sly_is_code( $the_coupon, SLY_BULK_CODE ) ) ? true : $allow;
}, 10, 2 );

// When a single-use code replaces another, say so (classic cart).
add_filter( 'woocommerce_apply_individual_use_coupon', function ( $keep, $the_coupon, $applied ) {
	$removed = array_diff( array_map( 'wc_strtolower', (array) $applied ), array( wc_strtolower( $the_coupon->get_code() ) ) );
	if ( $removed && function_exists( 'wc_add_notice' ) && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		wc_add_notice(
			sprintf(
				/* translators: 1: new code, 2: removed code(s) */
				__( 'Only one discount per order — %1$s has replaced %2$s.', 'sly-pebble-lite' ),
				strtoupper( $the_coupon->get_code() ),
				strtoupper( implode( ', ', $removed ) )
			),
			'notice'
		);
	}
	return $keep;
}, 10, 3 );

// Success messages.
add_filter( 'woocommerce_coupon_message', function ( $msg, $msg_code, $coupon ) {
	if ( WC_Coupon::WC_COUPON_SUCCESS !== $msg_code || ! $coupon instanceof WC_Coupon ) {
		return $msg;
	}
	if ( sly_is_code( $coupon, SLY_FIRST_ORDER_CODE ) ) {
		return __( 'SLY20 applied — 20% off your first order. (First-time buyers only, one use per customer.)', 'sly-pebble-lite' );
	}
	if ( sly_is_code( $coupon, SLY_BULK_CODE ) ) {
		return sprintf( __( 'COMFYAS applied — %d%% off your bulk order.', 'sly-pebble-lite' ), sly_bulk_pct_for_qty( sly_cart_item_count() ) );
	}
	return $msg;
}, 10, 3 );

// ── SLY20 final check when the order is placed ──────────────────────────────
function sly_order_has_code( $codes, $code ) {
	foreach ( (array) $codes as $c ) {
		if ( wc_strtolower( wc_format_coupon_code( $c ) ) === $code ) {
			return true;
		}
	}
	return false;
}

// Block checkout (Store API).
add_action( 'woocommerce_store_api_checkout_update_order_from_request', function ( $order ) {
	if ( ! $order instanceof WC_Order || ! sly_order_has_code( $order->get_coupon_codes(), SLY_FIRST_ORDER_CODE ) ) {
		return;
	}
	if ( sly_customer_has_prior_order( $order->get_customer_id(), $order->get_billing_email(), $order->get_id() ) ) {
		if ( function_exists( 'WC' ) && WC()->cart ) {
			WC()->cart->remove_coupon( SLY_FIRST_ORDER_CODE );
			WC()->cart->calculate_totals();
		}
		$msg = sly_first_order_fail_message() . ' ' . __( 'We\'ve removed the code — please check your new total and place your order again.', 'sly-pebble-lite' );
		if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'sly_first_order_only', $msg, 400 );
		}
		throw new Exception( $msg );
	}
}, 10, 1 );

// Classic checkout (theme falls back to [woocommerce_checkout] if blocks are missing).
add_action( 'woocommerce_after_checkout_validation', function ( $data, $errors ) {
	if ( ! function_exists( 'WC' ) || ! WC()->cart || ! sly_order_has_code( WC()->cart->get_applied_coupons(), SLY_FIRST_ORDER_CODE ) ) {
		return;
	}
	$email = isset( $data['billing_email'] ) ? $data['billing_email'] : '';
	if ( sly_customer_has_prior_order( get_current_user_id(), $email ) ) {
		WC()->cart->remove_coupon( SLY_FIRST_ORDER_CODE );
		WC()->session->set( 'refresh_totals', true );
		$errors->add( 'sly_first_order_only', sly_first_order_fail_message() . ' ' . __( 'We\'ve removed the code — please check your new total and place your order again.', 'sly-pebble-lite' ) );
	}
}, 10, 2 );

// ── Code hints ──────────────────────────────────────────────────────────────
function sly_discount_hint_html() {
	return '<p class="sly-code-hint">'
		. wp_kses_post( __( 'First-time buyer? Use <strong>SLY20</strong> for 20% off your first order.', 'sly-pebble-lite' ) ) . ' '
		. wp_kses_post( __( 'Buying 7+ items? Use <strong>COMFYAS</strong> for 15–25% off.', 'sly-pebble-lite' ) ) . ' '
		. '<span>' . esc_html__( 'One code per order.', 'sly-pebble-lite' ) . '</span></p>';
}

// Classic cart: under the coupon box.
add_action( 'woocommerce_cart_coupon', function () {
	echo sly_discount_hint_html(); // phpcs:ignore WordPress.Security.EscapeOutput
} );

// Block checkout: small note above the checkout form.
add_filter( 'render_block', function ( $html, $block ) {
	if ( empty( $block['blockName'] ) || 'woocommerce/checkout' !== $block['blockName'] ) {
		return $html;
	}
	return '<div class="sly-code-hint sly-code-hint--checkout">' . sly_discount_hint_html() . '</div>' . $html;
}, 10, 2 );

// Classic checkout coupon toggle.
add_filter( 'woocommerce_checkout_coupon_message', function ( $msg ) {
	return $msg . ' ' . wp_strip_all_tags( __( '(SLY20 = 20% off your first order · COMFYAS = 15–25% off 7+ items)', 'sly-pebble-lite' ) );
} );

add_action( 'wp_head', function () {
	if ( ! function_exists( 'is_cart' ) || ! ( is_cart() || is_checkout() ) ) {
		return;
	}
	?>
	<style id="sly-code-hint-css">
	.sly-code-hint{flex:1 1 100%;width:100%;margin:.5rem 0 0!important;font-size:.8rem;line-height:1.5;color:var(--sly-ink,#5c5c5c)}
	.sly-code-hint strong{color:var(--sly-ink,#222);letter-spacing:.03em}
	.sly-code-hint span{opacity:.7}
	.sly-code-hint--checkout{max-width:1200px;margin:0 auto 1rem;padding:.75rem 1rem;border:1px dashed var(--sly-line,#ddd);border-radius:6px;background:#fafafa}
	.sly-code-hint--checkout .sly-code-hint{margin:0!important}
	</style>
	<?php
}, 20 );
