<?php
/**
 * Single product template — SLY Pebble Lite.
 *
 * @package sly-pebble-lite
 */

defined( 'ABSPATH' ) || exit;

global $product;

do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

if ( ! $product instanceof WC_Product || ! $product->is_visible() ) {
	return;
}

// ── Gallery items ─────────────────────────────────────────────────────────────
$main_image_id = $product->get_image_id();
$gallery_ids   = $product->get_gallery_image_ids();
$image_ids     = array_values( array_filter( array_merge( [ $main_image_id ], $gallery_ids ) ) );

if ( empty( $image_ids ) ) {
	$image_ids = [ 0 ];
}

$sly_video_mp4    = get_post_meta( $product->get_id(), '_sly_video_mp4', true );
$sly_video_webm   = get_post_meta( $product->get_id(), '_sly_video_webm', true );
$sly_video_poster = get_post_meta( $product->get_id(), '_sly_video_poster', true );
$sly_video_pos    = get_post_meta( $product->get_id(), '_sly_video_position', true );
$sly_has_video    = ! empty( $sly_video_mp4 );

if ( '' === $sly_video_pos ) {
	$sly_video_pos = '1';
}

$gallery_items = array_map( function ( $id ) {
	return [ 'type' => 'image', 'id' => $id ];
}, $image_ids );

if ( $sly_has_video ) {
	$video_item = [
		'type'   => 'video',
		'mp4'    => $sly_video_mp4,
		'webm'   => $sly_video_webm,
		'poster' => $sly_video_poster,
	];
	if ( '0' === $sly_video_pos ) {
		array_unshift( $gallery_items, $video_item );
	} elseif ( 'last' === $sly_video_pos ) {
		$gallery_items[] = $video_item;
	} else {
		$pos = min( (int) $sly_video_pos, count( $gallery_items ) );
		array_splice( $gallery_items, $pos, 0, [ $video_item ] );
	}
}

$gallery_items = array_slice( $gallery_items, 0, 6 );
$total_items   = count( $gallery_items );

// ── Review meta ───────────────────────────────────────────────────────────────
$sly_rev_rating = get_post_meta( $product->get_id(), '_sly_review_rating', true );
$sly_rev_quote  = get_post_meta( $product->get_id(), '_sly_review_quote', true );
$sly_rev_author = get_post_meta( $product->get_id(), '_sly_review_author', true );
$sly_rev_rating = ( '' !== $sly_rev_rating ) ? (int) $sly_rev_rating : 5;
$sly_rev_quote  = ( '' !== $sly_rev_quote ) ? $sly_rev_quote : 'The support pouch is a bloody big upgrade from regular briefs. No more awkward slipping, no more subtle public repacking missions.';
$sly_rev_author = ( '' !== $sly_rev_author ) ? $sly_rev_author : '— Trev, Melbourne';

// ── Discount pricing ──────────────────────────────────────────────────────────
$sly_price      = (float) $product->get_price();
$show_discounts = $sly_price > 0;
$price_d10      = $show_discounts ? wc_price( round( $sly_price * 0.90, 2 ) ) : '';
$price_d15      = $show_discounts ? wc_price( round( $sly_price * 0.85, 2 ) ) : '';
$price_d25      = $show_discounts ? wc_price( round( $sly_price * 0.75, 2 ) ) : '';

// ── Stock warning ─────────────────────────────────────────────────────────────
$stock_warning = '';
if ( $product->managing_stock() ) {
	$sq = (int) $product->get_stock_quantity();
	if ( $sq > 0 && $sq <= 10 ) {
		/* translators: %d: number of items in stock */
		$stock_warning = sprintf( __( 'Only %d left in stock — order soon.', 'sly-pebble-lite' ), $sq );
	}
}

// ── Descriptions ─────────────────────────────────────────────────────────────
$full_desc  = $product->get_description();
$short_desc = preg_replace( '/\[1_2_3_u_pouch[^\]]*\]/i', '', (string) $product->get_short_description() );
$short_desc = trim( (string) $short_desc );
?>

<article id="product-<?php the_ID(); ?>" <?php wc_product_class( 'sly-pd-layout', $product ); ?>>

<div class="sly-pd">

	<!-- ═══════════════ GALLERY COLUMN ═══════════════ -->
	<div class="sly-pd-gallery-col">

		<!-- Single image set — 2-col 9:16 grid on desktop, 1:1 carousel on mobile -->
		<div class="sly-pd-slides" data-pd-slides>
			<?php foreach ( $gallery_items as $ci => $ci_item ) : ?>
				<div class="sly-pd-slide <?php echo $ci < 2 ? 'sly-pd-slide--portrait' : 'sly-pd-slide--square'; ?>" data-pd-slide="<?php echo (int) $ci; ?>">
					<?php if ( 'video' === $ci_item['type'] ) : ?>
						<video autoplay muted loop playsinline
							<?php if ( ! empty( $ci_item['poster'] ) ) : ?>poster="<?php echo esc_url( $ci_item['poster'] ); ?>"<?php endif; ?>>
							<source src="<?php echo esc_url( $ci_item['mp4'] ); ?>" type="video/mp4">
							<?php if ( ! empty( $ci_item['webm'] ) ) : ?>
								<source src="<?php echo esc_url( $ci_item['webm'] ); ?>" type="video/webm">
							<?php endif; ?>
						</video>
					<?php else : ?>
						<?php echo $ci_item['id']
							? wp_get_attachment_image( $ci_item['id'], 'woocommerce_single', false, [ 'loading' => 0 === $ci ? 'eager' : 'lazy' ] )
							: wc_placeholder_img( 'woocommerce_single' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>

		<!-- Dots — visible on both desktop and mobile -->
		<?php if ( $total_items > 1 ) : ?>
		<div class="sly-pd-dots" data-pd-dots>
			<?php for ( $d = 0; $d < $total_items; $d++ ) : ?>
				<button type="button"
					class="sly-pd-dot<?php echo 0 === $d ? ' is-active' : ''; ?>"
					data-pd-dot="<?php echo (int) $d; ?>"
					aria-label="<?php printf( esc_attr__( 'Image %1$d of %2$d', 'sly-pebble-lite' ), $d + 1, $total_items ); ?>">
				</button>
			<?php endfor; ?>
		</div>
		<?php endif; ?>

	</div><!-- .sly-pd-gallery-col -->


	<!-- ═══════════════ INFO COLUMN ═══════════════ -->
	<div class="sly-pd-info">

		<!-- Title -->
		<h1 class="sly-pd-title"><?php the_title(); ?></h1>

		<!-- Price -->
		<div class="sly-pd-price">
			<?php echo wp_kses_post( $product->get_price_html() ); ?>
		</div>

		<!-- Short description + key features -->
		<?php if ( '' !== $short_desc ) : ?>
		<div class="sly-pd-excerpt">
			<?php echo wp_kses_post( wpautop( $short_desc ) ); ?>
		</div>
		<?php endif; ?>

		<!-- Review Spotlight -->
		<div class="sly-pd-review">
			<div class="sly-pd-review-stars" aria-label="<?php printf( esc_attr__( '%d out of 5 stars', 'sly-pebble-lite' ), $sly_rev_rating ); ?>">
				<?php for ( $s = 1; $s <= 5; $s++ ) : ?>
					<span class="sly-pd-star<?php echo $s <= $sly_rev_rating ? ' is-filled' : ''; ?>" aria-hidden="true">&#9733;</span>
				<?php endfor; ?>
			</div>
			<blockquote class="sly-pd-review-quote">
				<p><?php echo esc_html( $sly_rev_quote ); ?></p>
				<cite><?php echo esc_html( $sly_rev_author ); ?></cite>
			</blockquote>
		</div>

		<!-- Stock warning -->
		<?php if ( '' !== $stock_warning ) : ?>
		<p class="sly-pd-stock-warning"><?php echo esc_html( $stock_warning ); ?></p>
		<?php endif; ?>

		<!-- ── Purchase zone ──────────────────────────────────────────── -->
		<div class="sly-pd-purchase" data-atc-zone>

			<!-- Size guide link -->
			<a href="<?php echo esc_url( home_url( '/size_chart/size-guide/' ) ); ?>"
				class="sly-pd-sg-link"
				target="_blank"
				rel="noopener noreferrer">
				<?php esc_html_e( 'Size Guide &rarr;', 'sly-pebble-lite' ); ?>
			</a>

			<!-- WooCommerce add-to-cart form -->
			<div class="sly-add-to-cart sly-pd-wc">
				<?php woocommerce_template_single_add_to_cart(); ?>
			</div>

			<!-- Bulk discount table -->
			<?php if ( $show_discounts ) : ?>
			<div class="sly-pd-discounts">
				<p class="sly-pd-discounts-hdr">
					<span><?php esc_html_e( 'Added At Checkout', 'sly-pebble-lite' ); ?></span>
					<span class="sly-pd-discounts-hdr__right"><?php esc_html_e( "Don't Pay Full Price", 'sly-pebble-lite' ); ?></span>
				</p>
				<table class="sly-pd-discounts-tbl">
					<tbody>
						<tr>
							<td><?php esc_html_e( 'Buy 4 Get 10% Off', 'sly-pebble-lite' ); ?></td>
							<td><?php echo $price_d10; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Buy 7 Get 15% Off', 'sly-pebble-lite' ); ?></td>
							<td><?php echo $price_d15; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Buy 15 Get 25% Off', 'sly-pebble-lite' ); ?></td>
							<td><?php echo $price_d25; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						</tr>
					</tbody>
				</table>
				<p class="sly-pd-discounts-note"><?php esc_html_e( 'This adds the discount automatically at checkout.', 'sly-pebble-lite' ); ?></p>
			</div>
			<?php endif; ?>

		</div><!-- .sly-pd-purchase -->

		<!-- Trust strip -->
		<div class="sly-pd-trust">
			<span class="sly-pd-trust-item">&#10003; <?php esc_html_e( 'Free AU shipping over $100', 'sly-pebble-lite' ); ?></span>
			<span class="sly-pd-trust-item">&#8617; <?php esc_html_e( 'Easy returns', 'sly-pebble-lite' ); ?></span>
			<span class="sly-pd-trust-item">&#9919; <?php esc_html_e( 'Secure checkout', 'sly-pebble-lite' ); ?></span>
		</div>

		<!-- About the product -->
		<?php if ( $full_desc ) : ?>
		<div class="sly-pd-about">
			<p class="sly-pd-about-label"><?php esc_html_e( 'About the Product', 'sly-pebble-lite' ); ?></p>
			<div class="sly-pd-about-content">
				<?php echo wp_kses_post( wpautop( $full_desc ) ); ?>
			</div>
		</div>
		<?php endif; ?>

		<!-- Brand tagline + expandable tabs -->
		<div class="sly-pd-brand">

			<div class="sly-pd-brand-tagline">
				<p><?php esc_html_e( 'Cheeky by nature.', 'sly-pebble-lite' ); ?></p>
				<p><?php esc_html_e( 'Obsessed with comfort.', 'sly-pebble-lite' ); ?></p>
				<p><?php esc_html_e( 'Proudly Aussie.', 'sly-pebble-lite' ); ?></p>
			</div>

			<div class="sly-pd-tabs">

				<div class="sly-pd-tab">
					<button type="button" class="sly-pd-tab-trigger" aria-expanded="false">
						<?php esc_html_e( 'Care &amp; Cleaning', 'sly-pebble-lite' ); ?>
						<span class="sly-pd-tab-icon" aria-hidden="true">+</span>
					</button>
					<div class="sly-pd-tab-content" hidden>
						<p><?php esc_html_e( 'Machine wash cold (30°C) on a gentle cycle. Do not bleach. Do not tumble dry — hang to dry for best results. SLY fabrics are pre-shrunk and wash-stable; they soften with every wash without losing their shape.', 'sly-pebble-lite' ); ?></p>
					</div>
				</div>

				<div class="sly-pd-tab">
					<button type="button" class="sly-pd-tab-trigger" aria-expanded="false">
						<?php esc_html_e( 'Fabric', 'sly-pebble-lite' ); ?>
						<span class="sly-pd-tab-icon" aria-hidden="true">+</span>
					</button>
					<div class="sly-pd-tab-content" hidden>
						<p><?php esc_html_e( 'Engineered from a premium microfibre blend — breathable, moisture-wicking, and ultra-soft against skin. The INNER POUCH is constructed with structured yet stretch-responsive fabric so it holds its shape all day without restricting movement. Our bamboo range uses natural bamboo-derived fibres for a buttery-smooth finish with natural temperature regulation.', 'sly-pebble-lite' ); ?></p>
					</div>
				</div>

				<div class="sly-pd-tab">
					<button type="button" class="sly-pd-tab-trigger" aria-expanded="false">
						<?php esc_html_e( 'Shipping', 'sly-pebble-lite' ); ?>
						<span class="sly-pd-tab-icon" aria-hidden="true">+</span>
					</button>
					<div class="sly-pd-tab-content" hidden>
						<p><?php esc_html_e( 'Free standard shipping on Australian orders over $100. Express shipping available at checkout. All orders dispatched within 1–2 business days. You\'ll receive a tracking number via email as soon as your order leaves the warehouse.', 'sly-pebble-lite' ); ?></p>
					</div>
				</div>

				<div class="sly-pd-tab">
					<button type="button" class="sly-pd-tab-trigger" aria-expanded="false">
						<?php esc_html_e( 'Returns', 'sly-pebble-lite' ); ?>
						<span class="sly-pd-tab-icon" aria-hidden="true">+</span>
					</button>
					<div class="sly-pd-tab-content" hidden>
						<p><?php esc_html_e( 'SLY stands behind the fit. If something isn\'t right, contact the team within 30 days of delivery. Items must be unworn, unwashed, and with tags attached to be eligible for return. We\'ll sort you out — no runaround, no hassle.', 'sly-pebble-lite' ); ?></p>
					</div>
				</div>

			</div><!-- .sly-pd-tabs -->
		</div><!-- .sly-pd-brand -->

		<!-- Homepage button -->
		<div class="sly-pd-home-btn">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="sly-button">
				<?php esc_html_e( 'Back to Home', 'sly-pebble-lite' ); ?>
			</a>
		</div>

	</div><!-- .sly-pd-info -->

</div><!-- .sly-pd -->

</article><!-- #product-... -->

<!-- Sticky add-to-cart bar -->
<div class="sly-sticky-atc" data-sticky-atc aria-hidden="true">
	<div class="sly-sticky-atc__inner container">
		<div class="sly-sticky-atc__info">
			<span class="sly-sticky-atc__title"><?php echo esc_html( $product->get_name() ); ?></span>
			<span class="sly-sticky-atc__price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
		</div>
		<?php if ( $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() ) : ?>
			<button type="button"
				class="sly-button sly-sticky-atc__button"
				data-sticky-atc-btn
				data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"
				data-adding-text="<?php esc_attr_e( 'Adding…', 'sly-pebble-lite' ); ?>">
				<?php esc_html_e( 'Add to Cart', 'sly-pebble-lite' ); ?>
			</button>
		<?php else : ?>
			<a class="sly-button sly-sticky-atc__button" href="#product-<?php the_ID(); ?>">
				<?php esc_html_e( 'Select Options', 'sly-pebble-lite' ); ?>
			</a>
		<?php endif; ?>
	</div>
</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
